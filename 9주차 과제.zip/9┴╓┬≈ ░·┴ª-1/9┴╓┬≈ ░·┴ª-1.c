#pragma warning(disable:4996)
#pragma warning(disable:6031)
#include <stdio.h>
int main(void) {
	printf("Hello World!\n");
	return 0;
}